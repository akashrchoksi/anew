IndexController.$inject = ['$scope', '$http', '$rootScope', '$window', '$location', 'UserService', '$route'];

IndexController.routes = {
    companyView: {
        resolve: {
            company(UserService, $route, $rootScope) {
                return new Promise(
                    (resolve, reject) => {
                        UserService.getCompany($route.current.params.id).then(
                            function (response) {
                                if (Object.hasOwnProperty.call(response, 'data')
                                    &&Object.hasOwnProperty.call(response.data, 'companies')
                                ) {
                                    $rootScope.company = response.data.companies[0];
                                    resolve(true);
                                }
                            }
                        )
                    }
                );
            }
        },
        templateUrl: '/company/view.html',
        controller: 'IndexController'
    },
    account: {
        resolve: {
            loadAccount(UserService, $route, $rootScope) {
                return new Promise(
                    (resolve, reject) => {
                        UserService.loadAccount().then(
                            function (response) {
                                if (Object.hasOwnProperty.call(response, 'data')
                                    && Object.hasOwnProperty.call(response.data, 'userInfo')
                                ) {
                                    $rootScope.userInfo = response.data.userInfo;
                                    resolve(true);
                                }
                            }
                        )
                    }
                )
            }
        },
        templateUrl: '/account.html',
        controller: 'IndexController'
    }
};

function IndexController ($scope, $http, $rootScope, $window, $location, UserService, $route) {

    triggerStorageChange($rootScope.user);

    $scope.newCompany = {
        name: '',
        description: '',
        locations: '',
        employeeCount: '',
        foundedYear: '',
        website: '',
        photo: ''
    };

    $scope.foundedYears = new Array(50).fill().map((_, i) => new Date().getFullYear() - i);

    $scope.invite = {
        email: '',
        hash: ''
    };

    if ($rootScope.user && $rootScope.user.role === 'seeker' && $route.current.$$route.originalPath === '/') {
        $location.path('/search').replace().reload(false);
    }

    $scope.setRole = function (role) {
        $http({
            url: '/local-api/user/set-role',
            method: 'POST',
            data: {role}
        }).then(function (response) {
            if (Object.prototype.hasOwnProperty.call(response, 'data')
                && Object.prototype.hasOwnProperty.call(response.data, 'user')
                && Object.prototype.hasOwnProperty.call(response.data.user, 'role')
            ) {
                $rootScope.user.role = response.data.user.role;
                $window.location.reload();
            }
        });
    };

    $scope.createCompany = function () {
        app.triggerInput('#pac-input');
        $http({
            url: '/local-api/company/create',
            method: 'POST',
            data: $scope.newCompany
        }).then(function (response) {
            if (response && Object.prototype.hasOwnProperty.call(response, 'data')
                && response && Object.prototype.hasOwnProperty.call(response.data, 'company')
            ) {
                $window.location.reload();
            }

            setErrors(response, $rootScope);
        })
    };

    $scope.createInvite = function (email = false) {
        $http({
            url: '/local-api/invite/create',
            method: 'POST',
            data: {
                companyId: $rootScope.company.id,
                email: email ? email : $scope.invite.email
            }
        }).then(
            function (response) {
                if (response && Object.prototype.hasOwnProperty.call(response, 'data')
                    && response && Object.prototype.hasOwnProperty.call(response.data, 'invite')
                ) {
                    if (response.data.created) {
                        $rootScope.company.CompanyInvites.push(response.data.invite);
                    } else {
                        $rootScope.info = `Invite email resent to ${response.data.invite.email}`;
                    }

                    $scope.invite.email = '';
                }

                setErrors(response, $rootScope);
            }
        )
    };

    $scope.useInvite = function () {
        $http({
            url: '/local-api/invite/use',
            method: 'POST',
            data: $scope.invite
        }).then(
            function (response) {
                if (response && Object.prototype.hasOwnProperty.call(response, 'data')
                    && response && Object.prototype.hasOwnProperty.call(response.data, 'companies')
                ) {
                    $rootScope.company = response.data.companies[0];
                }

                setErrors(response, $rootScope);
            }
        )
    };

    $scope.cancelInvite = function (invite, status) {
        UserService.cancelInvite(invite.id, status).then(
            function (response) {
                if (response && Object.prototype.hasOwnProperty.call(response, 'data')
                    && response && Object.prototype.hasOwnProperty.call(response.data, 'invite')
                    && Object.prototype.hasOwnProperty.call(response.data.invite, 'status')
                ) {
                    invite.status = response.data.invite.status;
                }

                setErrors(response, $rootScope);
            }
        )
    };

    $scope.createJobApply = function (key, job) {
        UserService.createJobApply(job.id).then(
            function (response) {

                if (response && response.data && response.data.apply) {
                    $rootScope.company.Jobs[key].applies.push(response.data.apply);
                }

                setErrors(response, $rootScope);
            }
        );
    };

    $scope.updateStatusJob = updateJobStatus(UserService);

    angular.element(document).ready(function () {
        initAutocomplete();
    });
}

app.controller('IndexController', IndexController);
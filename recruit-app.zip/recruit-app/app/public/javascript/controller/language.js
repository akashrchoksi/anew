LanguageController.$inject = ['$scope', '$http', '$window', '$route'];

function LanguageController ($scope, $http, $window, $route) {

    $scope.setLanguage = function (lang) {
        $http({
            url: '/local-api/info/language',
            method: 'POST',
            data: {lang}
        }).then(function (response) {
            if (Object.prototype.hasOwnProperty.call(response, 'data')
                && Object.prototype.hasOwnProperty.call(response.data, 'change')
                && response.data.change === 'Language change'
            ) {
                $window.location.reload();
            }
        });
    };
}

app.controller('LanguageController', LanguageController);
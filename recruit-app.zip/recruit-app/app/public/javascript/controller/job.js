JobController.$inject = ['$scope', '$http', '$rootScope', '$location', 'UserService', 'Upload'];

JobController.resolve = {
    employments(JobService, $rootScope) {
        return new Promise(
            (resolve, reject) => {
                JobService.getEmploymentTypes().then(
                    function (response) {
                        if (response && response.data && response.data.employmentTypes) {
                            $rootScope.employmentTypes = response.data.employmentTypes;
                            resolve(true);
                        } else {
                            resolve(false);
                        }
                    }
                ).catch(
                    function () {
                        resolve(false);
                    }
                )
            }
        )
    },
    job(JobService, $route, $rootScope) {
        return new Promise(
            (resolve, reject) => {
                JobService.findJob($route.current.params.jobId).then(
                    function (response) {
                        if (response && response.data && response.data.job) {
                            $rootScope.job = response.data.job;

                            response.data.job.skills = response.data.job.skillJobs.map(
                                skillJob => {
                                    return skillJob.skill.name
                                }
                            ).join(',');
                            resolve(response.data.job);

                        } else {
                            resolve(null);
                        }
                    }
                )
            }
        )
    }
};

JobController.routes = {
    createJob: {
        templateUrl: '/job/create.html',
        resolve: {
            employments: JobController.resolve.employments
        },
        controller: 'JobController'
    },
    editJob: {
        templateUrl: '/job/create.html',
        controller: 'JobController',
        resolve: {
            employments: JobController.resolve.employments,
            job: JobController.resolve.job
        }
    },
    showJob: {
        templateUrl: '/job/job.html',
        controller: 'JobController',
        resolve: {
            job: JobController.resolve.job
        }
    },
    shareJob: {
        templateUrl: '/share-buttons.html',
        controller: 'JobController',
        resolve: {
            job: JobController.resolve.job
        }
    }
};

function JobController ($scope, $http, $rootScope, $location, UserService, Upload) {

    triggerStorageChange($rootScope.user);

    const defaultPublicFields = {
        title: true,
        shortDescription: true,
        longDescription: true,
        employmentType: true,
        category: true,
        annualPay: true,
        user: true,
        companyId: true,
        skills: true,
        locations: true,
    };

    $scope.range = false;

    if ($rootScope.job) {
        $scope.job = $rootScope.job;
        let selfPublicFields = defaultPublicFields;
        for (const field in selfPublicFields) {
            if ($scope.job.publicFields.indexOf(field) === -1) {
                selfPublicFields[field] = false;
            }
        }
        if (false === Array.isArray($scope.job.annualPay)) {
            $scope.job.annualPay = [$scope.job.annualPay, $scope.job.annualPay];
        }

        $scope.range = $scope.job.annualPay[0] !== $scope.job.annualPay[1];

        $scope.job.publicFields = selfPublicFields;
        $rootScope.job = null;

    } else {
        $scope.job = {
            title: '',
            shortDescription: '',
            longDescription: '',
            employmentType: 'Contract Job',
            categoryId: null,
            annualPay: [0, 0],
            user: $rootScope.user ? $rootScope.user.id : '',
            companyId: '',
            skills: '',
            locations: '',
            publicFields: defaultPublicFields
        };
    }

    $scope.job.longDescription = $scope.job.longDescription.replace(/gt;/, '>').replace(/lt;/, '<');

    $scope.preview = false;

    if ($scope.company) {
        $scope.job.companyId = $rootScope.company.id;
    }

    $scope.updateStatusJob = updateJobStatus(UserService);
    $scope.createJobApply = getSendApplyFunc($rootScope, $scope, Upload);


    $scope.validateJob = function () {
        $scope.job.longDescription = $scope.longDescriptionInput.val();
        app.triggerInput('.pac-input');
        $http({
            url: '/local-api/job/validate',
            method: 'POST',
            data: $scope.job
        }).then(
            function (response) {
                if (response && response.data && response.data.success) {
                    $scope.preview = true;
                } else if (response && response.data && response.data.redirect) {
                    window.location.assign(response.data.redirect);
                }

                setErrors(response, $rootScope);
            }
        )
    };

    $scope.enableEdit = function () {
        $scope.preview = false;
    };

    $scope.postJob = function () {
        $scope.job.annualPay = !$scope.range ? [$scope.job.annualPay[0], $scope.job.annualPay[0]] : $scope.job.annualPay;
        $scope.job.activeRange = $scope.dateRange.selectedDates;
        app.triggerInput('#pac-input');

        let publicFields = [];
        for (const field in $scope.job.publicFields) {
            if ($scope.job.publicFields[field]) {
                publicFields.push(field);
            }
        }

        $http({
            url: '/local-api/job/create',
            method: 'POST',
            data: Object.assign($scope.job, {publicFields})
        }).then(
            function (response) {
                if (response && response.data && response.data.job) {
                    $location.path('/');
                } else if (response && response.data && response.data.redirect) {
                    window.location.assign(response.data.redirect);
                }

                setErrors(response, $rootScope);
            }
        )
    };

    $scope.applyNonLoggedInInit = function (job) {
        $scope.chosenJob = job;
        jQuery('#apply-non-logged-in').modal('toggle');
    };

    $scope.updateAnnualPay = function () {
        $scope.job.annualPay = $scope.job.employmentType === 'Contract Job' ? [10, 10] : [10000, 10000]
    };

    $scope.fetchChanges = function() {
        const ignoreFields = ['publicFields', 'id', 'createdAt', 'updatedAt', 'category', 'last', 'activeRange'];

        let point = false;
        $scope.job.changes = [];

        for (const version in $scope.job.jobVersions) {
            let changes = {};
            if (point) {

                for (const field in point) {
                    if (-1 === ignoreFields.indexOf(field)
                        && equalField(point[field], $scope.job.jobVersions[version][field])
                    ) {
                        changes[field] = {
                            old: point[field],
                            new: $scope.job.jobVersions[version][field]
                        };
                    }
                }

                if (Object.keys(changes).length === 0) {
                    changes.internal = true;
                }

                let resultChanges = {};
                resultChanges.created = $scope.job.jobVersions[version].createdAt;

                for (const field in changes) {
                    let value = changes[field];
                    let fieldName = field;

                    switch (fieldName) {
                        case 'categoryId':
                            fieldName = 'Category';
                            value = {
                                new: $scope.job.jobVersions[version].category.name,
                                old: point.category.name,
                            };
                            break;
                        case 'annualPay':
                            fieldName = 'Annual Pay';
                            value.new = value.new[0] === value.new[1] ? `$${value.new[0]}` : `$${value.new[0]} - $${value.new[1]}`;
                        default:
                            fieldName = fieldName.charAt(0).toUpperCase() + fieldName.slice(1)
                    }

                    resultChanges[fieldName] = value;
                }

                $scope.job.changes.push(resultChanges);
            }

            point = $scope.job.jobVersions[version];
        }
    };

    function equalField(pointField, newField) {

        if (Array.isArray(pointField)) {
            for (const key in pointField) {
                if (pointField[key] !== newField[key]) {
                    return true;
                }
            }

            return false;
        } else {
            return pointField !== newField;
        }

    }

    angular.element(function() {

        $scope.longDescriptionInput = $('textarea.froala[ng-model="job.longDescription"]');
        $scope.longDescriptionInput.froalaEditor();

        const dateRange = jQuery('.date-range');

        $scope.dateRange = dateRange.flatpickr({
            mode: 'range',
            defaultDate: [
                $rootScope.job && $rootScope.job.activeRange ? new Date($rootScope.job.activeRange[0]) : new Date(),
                $rootScope.job && $rootScope.job.activeRange ? new Date($rootScope.job.activeRange[1]) : new Date().fp_incr(30),
            ]
        });

        initAutocomplete();

        const tagsInput = jQuery('.tagsinput');

        tagsInput.tagsInput(
            {
                defaultText: 'skills',
                width: '100%',
                height: 'auto',
                onAddTag: () => {
                    angular.element(tagsInput).triggerHandler('input');
                }
            }

        );
    });
}

app.controller('JobController', JobController);
SearchController.$inject = ['$scope', '$http', '$rootScope', 'UserService', 'searchJobs', 'Upload'];

SearchController.routes = {
    searchJob: {
        templateUrl: '/job/search.html',
        resolve: {
            searchJobs(UserService, $rootScope) {
                let query = {};
                for (const field in $rootScope.search) {
                    if ($rootScope.search[field]) {
                        query[field] = $rootScope.search[field];
                    }
                }
                return UserService.searchJobs(query, 20, 1);
            }
        },
        controller: 'SearchController'
    }
};

function SearchController($scope, $http, $rootScope, UserService, searchJobs, Upload) {

    triggerStorageChange($rootScope.user);

    $scope.limit = 20;
    $scope.page = 1;
    $scope.pageRange = [];
    $scope.pageCount = 0;
    $scope.jobsCount = 0;

    $scope.apply = {
        firstName: '',
        lastName: '',
        email: '',
        cv: null
    };

    $scope.salarySlider = {
        translate: function(value) {
            return '$' + value;
        }
    };

    $scope.daysSlider = {
        translate: function(value) {
            return value + ' days';
        }
    };

    $scope.buildRange = function (count) {
        const firstPage = $scope.page - 3 > 0 ? $scope.page - 3 : 1;
        const lastPage = $scope.page + 3 < $scope.pageCount ? $scope.page + 3 : $scope.pageCount;
        $scope.pageCount = 0;

        for (let page = firstPage; page <= lastPage; page++) {
            $scope.pageRange.push(page);
            $scope.pageCount++;
        }
    };

    let query = {};
    for (const field in $rootScope.search) {
        if ($rootScope.search[field]) {
            query[field] = $rootScope.search[field];
        }
    }

    const responseCallback = function (response) {
        $rootScope.inSearch = true;

        if (response && response.data && typeof response.data.count !== 'undefined') {
            $scope.pageCount = Number.parseInt(response.data.count/$scope.limit) + 1;
            $scope.buildRange(response.data.count);
            $scope.jobsCount = response.data.count;
        }

        if (response && response.data && Array.isArray(response.data.jobs)) {
            $rootScope.jobsFound = response.data.jobs;
            $rootScope.inSearch = true;
        }
    };

    responseCallback(searchJobs);

    $rootScope.searchJob = function (page = 1, limit = 20) {
        app.triggerInput('#pac-input');
        let query = {};
        for (const field in $rootScope.search) {
            if ($rootScope.search[field]) {
                query[field] = $rootScope.search[field];
            }
        }
        $scope.page = page > 0 ? page : 1;
        $scope.limit = limit;

        UserService.searchJobs(query, limit, page).then(function (response) {
            responseCallback(response);
        });
    };

    $scope.createJobApply = getSendApplyFunc($rootScope, $scope, Upload);

    $scope.applyNonLoggedInInit = function (job) {
        $scope.chosenJob = job;
        jQuery('#apply-non-logged-in').modal('toggle');
    };

    angular.element(document).ready(
        function () {
            jQuery('[id^="collapse_details_"]').on('hidden.bs.collapse', function () {

                jQuery(`a.more[href="#${jQuery(this).attr('id')}"]`).show();
                jQuery(`a.less[href="#${jQuery(this).attr('id')}"]`).hide();
            }).on('shown.bs.collapse', function () {
                jQuery(`a.less[href="#${jQuery(this).attr('id')}"]`).show();
                jQuery(`a.more[href="#${jQuery(this).attr('id')}"]`).hide();
            });
        }
    )
}

app.controller('SearchController', SearchController);
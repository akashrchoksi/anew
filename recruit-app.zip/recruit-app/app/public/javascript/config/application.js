app.config(function ($routeProvider, $locationProvider) {

    $locationProvider.html5Mode({
        enabled: true,
        requireBase: false,
        rewriteLinks: 'internal-link'
    });

    const universalResolves = {
        user(UserService, $route, $rootScope) {
            return new Promise(
                (resolve, reject) => {
                    UserService.currentUser().then(function (response) {
                        if (response.data && response.data.user) {

                            $rootScope.user = response.data.user;

                            if (response.data.user.role === 'employer' && $route.current.$$route.originalPath !== '/company/:id') {

                                UserService.getCompanies().then(
                                    function (response) {
                                        if (Object.hasOwnProperty.call(response, 'data')
                                            &&Object.hasOwnProperty.call(response.data, 'companies')
                                        ) {
                                            $rootScope.company = response.data.companies.length > 0
                                                ? response.data.companies[0] : false;
                                            resolve(true);
                                        }
                                    }
                                )
                            } else {
                                resolve(true);
                            }
                        } else {
                            resolve(false);
                        }
                    });
                }
            );
        },
        categories(UserService, $rootScope) {
            return new Promise(
                (resolve, reject) => {
                    UserService.getCategories().then(function (response) {
                        if (response.data && response.data.categories) {
                            $rootScope.categories = response.data.categories;
                            resolve(true);
                        } else {
                            resolve(false);
                        }
                    })
                }
            )
        },
        baseUrl($rootScope, $http) {
            return new Promise(
                (resolve, reject) => {
                    $http({
                        url: '/local-api/info/base-url',
                        method: 'POST'
                    }).then(function (response) {
                        if (response.data && response.data.baseUrl) {
                            $rootScope.baseUrl = response.data.baseUrl;
                            resolve(true);
                        } else {
                            resolve(false);
                        }
                    })
                }
            )
        },
        search($rootScope) {
            return new Promise(
                (resolve, reject) => {
                    if (!$rootScope.search) {
                        $rootScope.search = {
                            keywords: '',
                            locations: '',
                            category: 0,
                            createdDayMin: 0,
                            createdDayMax: 60,
                            salaryMin: 0,
                            salaryMax: 100000,
                            categories: {},
                            employmentTypes: {},
                        };
                    }
                    $rootScope.inSearch = false;
                    resolve($rootScope.search);
                }
            )
        },
        employmentTypes($rootScope, UserService) {
            return new Promise(
                (resolve, reject) => {
                    UserService.employmentTypes().then(function (response) {
                        if (response && response.data && Array.isArray(response.data.employmentTypes)) {
                            $rootScope.employmentTypes = response.data.employmentTypes;
                            resolve(true);
                        } else {
                            resolve(false);
                        }
                    })
                }
            )
        },
        employeeCount($rootScope, UserService) {
            return new Promise(
                (resolve, reject) => {
                    UserService.employeeCounts().then(function (response) {
                        if (response && response.data && Array.isArray(response.data.employeeCounts)) {
                            $rootScope.employeeCounts = response.data.employeeCounts;
                            resolve(true);
                        } else {
                            resolve(false);
                        }
                    })
                }
            )
        },
        date($rootScope) {
            $rootScope.Date = function (args) {
                return new Date(args);
            };
        },
        statusStyles($rootScope) {
            $rootScope.statusStyles = {
                trash: 'text-danger',
                active: 'text-success',
                draw: 'text-warning',
            };
        }
    };

    const customRouteProvider = angular.extend({}, $routeProvider, {
        when: function(path, route) {
            route.resolve = (route.resolve) ? route.resolve : {};
            angular.extend(route.resolve, universalResolves);
            $routeProvider.when(path, route);
            return this;
        }
    });

    for (const routeName in routes) {
        customRouteProvider.when(routeName, routes[routeName]);
    }

    customRouteProvider.otherwise({
        templateUrl: '/404.html'
    });
});

function updateJobStatus(UserService) {
    return function (job, status) {
        UserService.updateStatusJob(job.id, status).then(function (response) {
            if (Object.prototype.hasOwnProperty.call(response, 'data')
                && Object.prototype.hasOwnProperty.call(response.data, 'job')
                && Object.prototype.hasOwnProperty.call(response.data.job, 'status')
            ) {
                job.status = response.data.job.status;
            }
        });
    };
}

function getSendApplyFunc($rootScope, $scope, Upload) {
    return function (job, data = {}, modal = false) {

        Upload.upload(
            {
                url: '/local-api/apply/create',
                method: 'POST',
                cv: $scope.cv,
                data: Object.assign({jobId: job.id}, data)
            }
        ).success(function (data) {

            if (data && data.apply) {
                job.applies.push(data.apply);

                if (modal) {
                    $scope.info = 'Successfully sent job request';

                    jQuery(modal).modal('hide');
                    $rootScope.errors = false;
                }
            }

            setErrors({data}, $rootScope);
        });
    };
}


function storageChange (event) {
    if(event.key === 'logged_in') {
        window.location.reload();
    }
}

function triggerStorageChange(user) {
    if (user) {
        window.localStorage.setItem('logged_in', true);
    } else {
        window.localStorage.setItem('logged_in', false);
    }
}

window.addEventListener('storage', storageChange, false);
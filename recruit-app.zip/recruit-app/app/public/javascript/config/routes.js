const routes = {
    '/': {
        templateUrl: '/index.html',
        controller: 'IndexController'
    },
    '/create-job': JobController.routes.createJob,
    '/edit-job/:jobId': JobController.routes.editJob,
    '/search': SearchController.routes.searchJob,
    '/company/:id': IndexController.routes.companyView,
    '/account': IndexController.routes.account,
    '/logout': {
        resolve: {
            run() {
                window.localStorage.setItem('logged_in', false);
                window.location.assign('/logout');
            }
        }
    },
    '/job/:jobId-:title': JobController.routes.showJob,
    '/share-job/:jobId': JobController.routes.shareJob
};
function setErrors(response, $rootScope) {
    $rootScope.errors = false;

    if (response && response.data && response.data.error) {
        $rootScope.errors = [response.data.error];
    }

    if (response && response.data && response.data.errors) {
        $rootScope.errors = response.data.errors;
    }
}

let app = angular.module('application', ['ngRoute', 'rzModule', 'ngFileUpload', 'ngSanitize']);

app.factory('UserService', function ($http) {
    return {
        getCompanies() {
            return $http({
                url: '/local-api/company/get',
                method: 'POST'
            });
        },
        currentUser() {
            return $http({
                url: '/local-api/user/current',
                method: 'POST'
            });
        },
        getCategories() {
            return $http({
                url: '/local-api/info/categories',
                method: 'POST'
            });
        },
        getCompany(companyId) {
            return $http({
                url: `/local-api/company/${companyId}`,
                method: 'GET'
            });
        },
        searchJobs(query, limit = 1, page = 1) {
            return $http({
                url: '/local-api/job/search',
                method: 'POST',
                data: Object.assign(query, {limit, page})
            });
        },
        employmentTypes() {
            return $http({
                url: '/local-api/info/employment-types',
                method: 'POST'
            });
        },
        employeeCounts() {
            return $http({
                url: '/local-api/info/employee-counts',
                method: 'POST'
            });
        },
        createJobApply(jobId, data = {}) {
            return $http({
                url: '/local-api/apply/create',
                method: 'POST',

            });
        },
        loadAccount(userId) {
            return $http({
                url: '/local-api/info/account',
                method: 'POST',
                data: {userId}
            });
        },
        updateStatusJob(jobId, status) {
            return $http({
                url: '/local-api/job/update-status',
                method: 'POST',
                data: {jobId, status}
            })
        },
        cancelInvite(invite, status) {
            return $http({
                url: '/local-api/invite/cancel',
                method: 'POST',
                data: {invite, status}
            })
        }
    };
}).factory('JobService', function ($http) {
    return {
        getEmploymentTypes() {
            return $http({
                url: '/local-api/info/employment-types',
                method: 'POST'
            })
        },
        findJob(id) {
            return $http({
                url: `/local-api/job/${id}`,
                method: 'POST'
            });
        }
    };
});

app.run(['$rootScope', '$http', function ($rootScope, $http) {

    $http({
        url: '/local-api/info/links',
        method: 'POST'
    }).then(function (response) {
        if (Object.prototype.hasOwnProperty.call(response, 'data')
            && Object.prototype.hasOwnProperty.call(response.data, 'links')
        ) {
            $rootScope.links = response.data.links;
        }
    });

}]);

app.directive("fileread", [function () {
    return {
        scope: {
            fileread: "="
        },
        link: function (scope, element, attributes) {
            element.bind("change", function (changeEvent) {
                let reader = new FileReader();
                reader.onload = function (loadEvent) {
                    scope.$apply(function () {
                        scope.fileread = loadEvent.target.result;
                    });
                };
                reader.readAsDataURL(changeEvent.target.files[0]);
            });
        }
    }
}]);

app.triggerInput = function (selector) {
    angular.element(jQuery(selector)).triggerHandler('input');
};
const db = appRequire('service', 'db');
const auth = appRequire('service', 'auth');
const {handleResponseError} = appRequire('service', 'error');

const findCompanies = function (token, where, response) {

    db.UserCompany.findAll(
        {
            where,
            include: [
                {
                    association: db.UserCompany.associations.Company,
                    include: [
                        {
                            association: db.Company.associations.Jobs,
                            include: [
                                {
                                    association: db.Job.associations.Company,
                                },
                                {
                                    association: db.Job.associations.SkillJobs,
                                    include: [
                                        {
                                            association: db.SkillJob.associations.skill
                                        }
                                    ]
                                },
                                {
                                    association: db.Job.associations.JobVersions,
                                },
                                {
                                    association: db.Job.associations.Applies,
                                    include: [
                                        {
                                            association: db.Apply.associations.UserInfo
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            association: db.Company.associations.Invites
                        }
                    ]
                }
            ],
            hooks: true
        }
    ).then(userCompanies => {

        if (userCompanies.length === 0) {
            return response.json(
                {
                    companies: []
                }
            );
        } else {
            userCompanies.map(userCompany => {

                auth.getUserDetails(token, function (data) {
                    const company = userCompany.company.toJSON();
                    company.userId = userCompany.user;

                    db.Job.putAdditionalFields(company.Jobs).then(jobs => {
                        if (data && data.user && data.user.id == userCompany.user) {
                            return response.json(
                                {
                                    companies: [company]
                                }
                            );
                        } else if (data && data.user && data.user.role === 'seeker') {

                            company.Jobs = company.Jobs.map(job => {
                                job.applies = job.applies.map(apply => apply.userInfoId);
                                return job;
                            });
                            return response.json(
                                {
                                    companies: [company]
                                }
                            );
                        } else {
                            company.Jobs = company.Jobs.map(job => {
                                delete job.applies;
                                return job;
                            });
                            return response.json(
                                {
                                    companies: [company]
                                }
                            );
                        }
                    }).catch(handleResponseError(response));
                });
            })
        }

    });
};

module.exports = findCompanies;
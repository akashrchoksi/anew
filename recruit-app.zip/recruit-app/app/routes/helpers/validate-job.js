const db = appRequire('service', 'db');

/**
 * @param job
 * @param companyId
 * @return {Promise}
 * @constructor
 */
function ValidateJob (job, companyId) {
    return new Promise(
        (resolve, reject) => {
            db.Company.findByPrimary(companyId)
                .then(
                    company => {
                        if (company === null) {
                            reject(
                                new db.Sequelize.ValidationError(null, [
                                    {
                                        message: 'Company is invalid'
                                    }
                                ])
                            )
                        }

                        const jobVersionModel = db.JobVersion.build(
                            {
                                title            : job.title,
                                shortDescription : job.shortDescription,
                                longDescription  : job.longDescription,
                                annualPay        : job.annualPay,
                                categoryId       : job.categoryId,
                                employmentType   : job.employmentType,
                                locations        : job.locations
                            }
                        );

                        jobVersionModel.validate().then(validationError => {
                            if (validationError) {
                                reject(validationError)
                            } else {

                                const jobModel = db.Job.build(
                                    Object.assign(job,
                                        {
                                            companyId: company.id
                                        }
                                    )
                                );

                                if (job.id) {
                                    jobModel.isNewRecord = false;
                                }

                                jobModel.validate().then(validationError => {
                                    if (validationError) {
                                        reject(validationError);
                                    } else {
                                        resolve(jobModel);
                                    }
                                })
                            }
                        });
                    }
                ).catch(
                error => {
                    reject(error);
                }
            );
        }
    )
}

module.exports = ValidateJob;
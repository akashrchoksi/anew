const auth = appRequire('service', 'auth');
const express = require('express');
const router  = express.Router();
const db = appRequire('service', 'db');
const {handleResponseError} = appRequire('service', 'error');

router.use((req, res, next) => {
    req.app.locals.baseUrl = `${process.env.SCHEMA}://${process.env.HOST}:${process.env.PORT}`;
    next();
});

router.use((req, res, next) => {
    gt.setLocale(req.session.lang || 'en_US');
    next();
});

router.get('/login', (req, res) => {
    if (req.query.token) {
        req.session.token = req.query.token;
        req.session.cookie.expires = new Date(Date.now() + 14 * 24 * 3600000);
        req.session.cookie.maxAge = 14 * 24 * 3600000;
        req.session.save();

        auth.getUserDetails(req.session.token, function (response) {

            const applyUser = new Promise(
                (resolve, reject) => {
                    if (response && response.user) {

                        if (req.query.role && response.user.role && -1 === ['seeker', 'employer'].indexOf(response.user.role)) {
                            auth.updateUser(req.session.token, {role: req.query.role}, function (response) {
                                if (response.success === true) {
                                    resolve(response.user);
                                } else {
                                    reject(new Error('Error while updating user role'));
                                }
                            });
                        } else {
                            resolve(response.user);
                        }
                    } else {
                        reject(new Error('Token is invalid'));
                    }
                }
            );

            applyUser.then(
                user => {

                    const storeUser = Object.assign(user, {
                        userId: user.id
                    });
                    delete storeUser.createdAt;
                    delete storeUser.updatedAt;
                    delete storeUser.role;
                    delete storeUser.id;

                    db.UserInfo.upsert(storeUser).then(
                        user => {
                            res.redirect(storeUser.role === 'seeker' ? '/search' : '/');
                        }
                    ).catch(
                        error => {
                            console.log(error)
                        }
                    )
                }
            ).catch(
                error => {
                    console.log(error)
                }
            );

        });
    }
});

router.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/');
});

router.get('/share-job/:id', (req, res) => {
    db.Job.find(
        {
            where: {
                id: req.params.id,
            },
            include: [
                {
                    association: db.Job.associations.Company
                }
        ]
        }

    ).then(
        job => {
            res.render('layout', {
                job: job.toJSON()
            })
        }
    ).catch(handleResponseError(res))
});


router.use('/local-api', require('./local-api/'));

router.get('/:view([a-z0-9-\/]+).html', (req, res) => {

    res.render(req.params.view, (error, str) => {
        if (error) {
            res.render('error', {error});
        } else {
            res.send(str);
        }
    });

});

router.get(['/:page([\\s\\d\\w-%\/]+)', '/'], (req, res) => {
    res.render('layout');
});

module.exports = router;
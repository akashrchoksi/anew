const express = require('express');
const router  = express.Router();
const auth = appRequire('service', 'auth');
const db = appRequire('service', 'db');
const {handleResponseError} = appRequire('service', 'error');

router.post('/current', (req, res) => {
    auth.getUserDetails(req.session.token, function (response) {
        if (response.success === true) {
            if (response && response.user) {
                db.UserInfo.find(
                    {
                        where: {
                            userId: response.user.id
                        }
                    }
                ).then(
                    userInfo => {
                        response.user.userInfo = userInfo.toJSON();
                        res.json(response);
                    }
                ).catch(handleResponseError(res));
            } else {
                res.render(response);
            }
        } else {
            res.json(false);
        }
    })
});

module.exports = router;
const express = require('express');
const router = express.Router();

router.use(require('./current'));
router.use(require('./set-role'));

module.exports = router;
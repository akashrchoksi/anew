const express = require('express');
const router  = express.Router();
const auth = appRequire('service', 'auth');

router.post('/set-role', (req, res) => {
    auth.updateUser(req.session.token, {role: req.body.role}, function (response) {
        if (response.success === true) {
            res.json(response);
        } else {
            res.json(false);
        }
    });
});

module.exports = router;
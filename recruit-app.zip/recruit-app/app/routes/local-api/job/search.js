const express = require('express');
const router = express.Router();
const db = appRequire('service', 'db');
const {handleResponseError} = appRequire('service', 'error');

router.post('/search', (req, res) => {
    let where = req.body;

    const page = req.body.page || 1;
    const limit = req.body.limit || 1;

    delete req.body.page;
    delete req.body.limit;

    if (where.keywords) {
        where = Object.assign(
            where,
            {
                $or: [
                    {title: {$ilike: `%${req.body.keywords}%`}},
                    {shortDescription: {$ilike: `%${req.body.keywords}%`}},
                    {longDescription: {$ilike: `%${req.body.keywords}%`}},
                ]
            }
        );

        delete where.keywords;
    }

    if (where.locations) {
        where = Object.assign(
            where,
            {
                $or: [
                    {locations: {$ilike: `%${req.body.locations}%`}}
                ]
            }
        );

        delete where.locations;
    }

    if (where.categories && Object.keys(where.categories).length > 0) {

        const $in = [];

        for (const categoryId in where.categories) {
            if (where.categories[categoryId] === true) {
                $in.push(categoryId);
            }
        }

        if ($in.length > 0) {
            where.categoryId = {$in};
        }

    }

    if (where.category && ! where.categories) {
        where.categoryId = req.body.category;
    }

    if (where.category) {
        delete where.category;
    }

    if (where.categories) {
        delete where.categories;
    }

    if (where.employmentTypes && Object.keys(where.employmentTypes).length > 0) {
        const $in = [];

        for (const employmentType in where.employmentTypes) {
            if (where.employmentTypes[employmentType] === true) {
                $in.push(employmentType);
            }
        }

        if ($in.length > 0) {
            where.employmentType = {$in};
        }
    }

    if (where.employmentTypes) {
        delete where.employmentTypes;
    }

    where.$and = [
        ['active_range[1] <= CURRENT_TIMESTAMP'],
        ['active_range[2] >= CURRENT_TIMESTAMP'],
        ['last = true']
    ];

    if (where.salaryMin) {
        where.$and.push([`annual_pay[1] >= ${where.salaryMin}`]);
        delete where.salaryMin;

    }

    if (where.salaryMax) {
        where.$and.push([`annual_pay[2] <= ${where.salaryMax}`]);
        delete where.salaryMax;
    }

    if (where.createdDayMin) {
        const date = new Date();
        date.setDate(date.getDate() - where.createdDayMin);

        where.createdAt = {$lte: date};
        delete where.createdDayMin;
    }

    if (where.createdDayMax) {
        const date = new Date();
        date.setDate(date.getDate() - where.createdDayMax);

        if (!where.createdAt) {
            where.createdAt = {};
        }

        where.createdAt.$gte = date;
        delete where.createdDayMax;
    }

    const topWhere = {status: db.Job.statuses.ACTIVE};

    const offset = limit * (page - 1);

    const include = [
        {
            association: db.Job.associations.Company
        },
        {
            association: db.Job.associations.Applies
        },
        {
            association: db.Job.associations.JobVersions,
            where,
            order: [['id', 'DESC']]
        },
        {
            association: db.Job.associations.SkillJobs,
            include: [
                {
                    association: db.SkillJob.associations.skill
                }
            ]
        },
    ];

    const order = [['createdAt', 'DESC']];

    db.Job.count({order, limit, offset, include, distinct: true, where: topWhere}).then(
        count => {

            db.Job.findAll({order, limit, offset, include, where: topWhere, distinct: true}).then(
                jobs => {
                    jobs = jobs.map(job => {

                        const resultJob = job.toJSON();
                        resultJob.applies = resultJob.applies.map(apply => apply.userInfoId);
                        return resultJob;
                    });

                    res.json({jobs, count});
                }
            ).catch(handleResponseError(res));
        }
    ).catch(handleResponseError(res));
});

module.exports = router;
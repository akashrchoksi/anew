const express = require('express');
const router = express.Router();
const db = appRequire('service', 'db');
const auth = appRequire('service', 'auth');
const {handleResponseError} = appRequire('service', 'error');

router.post('/update-status', (req, res) => {
    auth.getUserDetails(
        req.session.token, function (response) {
            if (response.hasOwnProperty('user')
                && response.user.role === 'employer') {
                db.Job.findByPrimary(Number.parseInt(req.body.jobId))
                    .then(
                        job => {
                            if (job === null) {
                                return res.json(
                                    {
                                        error: 'Job is invalid'
                                    }
                                );
                            }

                            db.Company.findByPrimary(Number.parseInt(job.companyId))
                                .then(
                                    company => {
                                        if (company === null) {
                                            return res.json(
                                                {
                                                    error: 'Company is invalid'
                                                }
                                            );
                                        }

                                        db.Job.update(
                                            {
                                                status: req.body.status
                                            },
                                            {
                                                where: {
                                                    id: req.body.jobId
                                                }
                                            }
                                        ).then(
                                            () => {
                                                res.json(
                                                    {
                                                        job: {
                                                            status: req.body.status
                                                        }
                                                    }
                                                )
                                            }
                                        ).catch(handleResponseError(res))
                                    }
                                ).catch(handleResponseError(res))
                        }).catch(handleResponseError(res))
            }
        });
});

module.exports = router;
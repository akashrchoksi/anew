const express = require('express');
const router  = express.Router();
const {handleResponseError} = appRequire('service', 'error');
const auth = appRequire('service', 'auth');
const ValidateJob = require('../../helpers/validate-job');

router.post('/validate', (req, res) => {
    auth.getUserDetails(req.session.token, function (response) {
        if (response.hasOwnProperty('user')) {
            ValidateJob(
                {
                    title: req.body.title,
                    shortDescription: req.body.shortDescription,
                    longDescription: req.body.longDescription,
                    annualPay: Number.parseInt(req.body.annualPay),
                    categoryId: req.body.categoryId,
                    employmentType: req.body.employmentType,
                    locations: req.body.locations
                },
                req.body.companyId
            ).then(
                () => {
                    res.json({
                        success: true
                    });
                }
            ).catch(handleResponseError(res))
        } else {
            res.json(
                {
                    redirect: '/'
                }
            )
        }

    });
});

module.exports = router;
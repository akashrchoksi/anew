const express = require('express');
const router  = express.Router();
const auth = appRequire('service', 'auth');
const db = appRequire('service', 'db');
const {handleResponseError} = appRequire('service', 'error');
const ValidateJob = require('../../helpers/validate-job');

router.post('/create', (req, res) => {
    auth.getUserDetails(req.session.token, function (response) {
        if (response.hasOwnProperty('user')) {

            db.UserInfo.find(
                {
                    where: {
                        userId: response.user.id
                    }
                }
            ).then(
                userInfo => {
                    if (userInfo === null) {
                        res.json({error: 'Permission denied'});
                    } else {

                        if (req.body.id) {
                            db.JobVersion.update(
                                {
                                    last: false
                                },
                                {
                                    where: {
                                        jobId: req.body.id
                                    }
                                }
                            );
                        }

                        ValidateJob(
                            {
                                id               : req.body.id,
                                title            : req.body.title,
                                shortDescription : req.body.shortDescription,
                                longDescription  : req.body.longDescription,
                                annualPay        : req.body.annualPay,
                                categoryId       : req.body.categoryId,
                                employmentType   : req.body.employmentType,
                                user             : response.user.id,
                                locations        : req.body.locations,
                                publicFields     : req.body.publicFields,
                                status           : db.Job.statuses.ACTIVE
                            },
                            req.body.companyId
                        ).then(job => {
                            job.save(
                                {
                                    version: {
                                        title            : req.body.title,
                                        shortDescription : req.body.shortDescription,
                                        longDescription  : req.body.longDescription,
                                        annualPay        : req.body.annualPay,
                                        categoryId       : req.body.categoryId,
                                        employmentType   : req.body.employmentType,
                                        userInfoId       : userInfo.id,
                                        locations        : req.body.locations,
                                        publicFields     : req.body.publicFields,
                                        activeRange      : req.body.activeRange
                                    }
                                }
                            ).then(
                                job => {
                                    req.body.skills.split(',').forEach(
                                        function (skill) {
                                            if (skill) {
                                                db.Skill.findOrCreate(
                                                    {
                                                        where: {
                                                            name: skill
                                                        }
                                                    }
                                                ).then(
                                                    response => {
                                                        const [skillInstance] = response;

                                                        db.SkillJob.findOrCreate(
                                                            {
                                                                where: {
                                                                    jobId: job.id,
                                                                    skillId: skillInstance.id
                                                                }
                                                            }
                                                        )
                                                    }
                                                )
                                            }
                                        }
                                    );

                                    res.json(
                                        {
                                            job: job
                                        }
                                    );
                                }
                            ).catch(handleResponseError(res));

                        }).catch(handleResponseError(res));
                    }
                }
            ).catch(handleResponseError(res))

        } else {
            res.json({
                redirect: '/'
            })
        }
    });
});

module.exports = router;
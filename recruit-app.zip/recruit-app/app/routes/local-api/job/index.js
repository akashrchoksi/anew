const express = require('express');
const router = express.Router();

router.use(require('./create'));
router.use(require('./find'));
router.use(require('./search'));
router.use(require('./update-status'));
router.use(require('./validate'));

module.exports = router;
const express = require('express');
const router  = express.Router();
const db = appRequire('service', 'db');
const {handleResponseError} = appRequire('service', 'error');

router.post('/:id(\\d+)', (req, res) => {
    db.Job.findByPrimary(
        req.params.id,
        {
            include: [
                {
                    association: db.Job.associations.Applies
                },
                {
                    association: db.Job.associations.Company
                },
                {
                    association: db.Job.associations.SkillJobs,
                    include: [
                        {
                            association: db.SkillJob.associations.skill
                        }
                    ]
                },
                {
                    association: db.Job.associations.JobVersions,
                    include: [
                        {
                            association: db.JobVersion.associations.Category
                        }
                    ]
                }
            ]
        }
    ).then(job => res.json({job})).catch(handleResponseError(res))
});

module.exports = router;
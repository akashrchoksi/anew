const express = require('express');
const router = express.Router();

router.use(require('./account'));
router.use(require('./base-url'));
router.use(require('./categories'));
router.use(require('./employee-counts'));
router.use(require('./employment-types'));
router.use(require('./language'));
router.use(require('./links'));

module.exports = router;
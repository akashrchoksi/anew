const express = require('express');
const router  = express.Router();
const db = appRequire('service', 'db');
const {handleResponseError} = appRequire('service', 'error');

router.post('/categories', (req, res) => {
    db.Category.findAll(
        {
            where: {
                parentId: null
            }
        }
    )
    .then(categories => {res.json({categories})})
    .catch(handleResponseError(res));
});

module.exports = router;
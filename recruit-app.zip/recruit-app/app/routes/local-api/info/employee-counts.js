const express = require('express');
const router  = express.Router();
const db = appRequire('service', 'db');

router.post('/employee-counts', (req, res) => {
    res.json(
        {
            employeeCounts: db.Company.employeeCount
        }
    );
});

module.exports = router;
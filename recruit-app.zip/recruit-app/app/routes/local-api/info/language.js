const express = require('express');
const router  = express.Router();
const auth = appRequire('service', 'auth');

router.post('/language', (req, res) => {
    if (req.body.lang) {
        req.session.lang = req.body.lang;
        req.session.save();
        res.json(
            {
                change: 'Language change'
            }
        );
    } else {
        res.json(
            {
                change: 'Something gone wrong'
            }
        );
    }
});

module.exports = router;
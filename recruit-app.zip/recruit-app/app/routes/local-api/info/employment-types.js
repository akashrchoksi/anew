const express = require('express');
const router  = express.Router();
const auth = appRequire('service', 'auth');
const db = appRequire('service', 'db');

router.post('/employment-types', (req, res) => {
    res.json(
        {
            employmentTypes: db.Job.employmentTypes
        }
    );
});

module.exports = router;
const express = require('express');
const router  = express.Router();
const auth = appRequire('service', 'auth');
const db = appRequire('service', 'db');
const {handleResponseError} = appRequire('service', 'error');

router.post('/account', (req, res) => {
    auth.getUserDetails(
        req.session.token,
        function (response) {
            if (response.hasOwnProperty('user')) {
                db.UserInfo.find(
                    {
                        where: {
                            userId: response.user.id
                        },
                        include: [
                            {
                                association: db.UserInfo.associations.Applies,
                                include: [
                                    {
                                        association: db.Apply.associations.Job
                                    }
                                ]
                            }
                        ]
                    }
                )
                .then(userInfo => res.json({userInfo}))
                .catch(handleResponseError(res));
            }
        })
});

module.exports = router;
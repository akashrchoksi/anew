const express = require('express');
const router  = express.Router();
const auth = appRequire('service', 'auth');

router.post('/base-url', (req, res) => {
    res.json(
        {
            baseUrl: req.app.locals.baseUrl
        }
    );
});

module.exports = router;
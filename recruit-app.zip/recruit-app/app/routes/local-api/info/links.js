const express = require('express');
const router  = express.Router();
const auth = appRequire('service', 'auth');

router.post('/links', (req, res) => {
    res.json(
        {
            links: auth.links
        }
    );
});

module.exports = router;
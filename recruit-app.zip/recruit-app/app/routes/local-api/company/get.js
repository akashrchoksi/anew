const express = require('express');
const router  = express.Router();
const auth = appRequire('service', 'auth');
const findCompanies = require('../../helpers/find-companies');

router.post('/get', (req, res) => {
    if (typeof req.body.companyId === 'undefined') {
        auth.getUserDetails(req.session.token, function (response) {

            if (response.hasOwnProperty('user')) {
                findCompanies(req.session.token, {user: response.user.id.toString()}, res);
            } else {
                res.json({
                    companies: []
                })
            }
        });
    } else {
        findCompanies(req.session.token, {companyId: Number.parseInt(req.body.companyId)}, res);
    }
});

module.exports = router;
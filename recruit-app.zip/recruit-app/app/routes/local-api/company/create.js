const express = require('express');
const router  = express.Router();
const auth = appRequire('service', 'auth');
const db = appRequire('service', 'db');
const {handleResponseError} = appRequire('service', 'error');

router.post('/create', (req, res) => {
    auth.getUserDetails(req.session.token, function (response) {
        if (response.hasOwnProperty('user')) {

            const companyInstance = db.Company.build(
                {
                    name         : req.body.name,
                    description  : req.body.description,
                    locations    : req.body.locations,
                    employeeCount: req.body.employeeCount,
                    foundedYear  : req.body.foundedYear,
                    website      : req.body.website
                }
            );

            function saveCompany() {
                companyInstance.save().then(
                    company => {

                        db.UserCompany.create(
                            {
                                companyId: company.id,
                                user     : response.user.id
                            }
                        );
                        res.json(
                            {
                                company: company
                            }
                        );
                    }
                ).catch(handleResponseError(res));
            }

            companyInstance.validate().then(
                validationResult => {

                    if (validationResult) {
                        res.json(
                            {
                                errors: validationResult.errors.map(error => error.message)
                            }
                        )
                    } else {
                        let photoExtension = req.body.photo.split(';')[0].match(/jpeg|png|gif/);
                        let base64Data = req.body.photo.replace(/^data:image\/\w+;base64,/, '');

                        if (!base64Data) {
                            saveCompany();
                        } else {

                            if (photoExtension !== null) {

                                const photoUrl = `/img/company/${companyInstance.name}.png`;

                                require('fs').writeFile(`${__base}/public/${photoUrl}`, base64Data, 'base64', function(err) {
                                    if (err) {
                                        res.json(
                                            {
                                                error: 'Photo is invalid'
                                            }
                                        );
                                    } else {
                                        companyInstance.photoUrl = photoUrl;
                                        saveCompany();
                                    }
                                });
                            } else {
                                res.json(
                                    {
                                        error: 'Photo is invalid'
                                    }
                                )
                            }

                        }
                    }
                }
            );
        }
    });
});

module.exports = router;
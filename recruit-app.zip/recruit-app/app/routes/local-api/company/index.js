const express = require('express');
const router = express.Router();

router.use(require('./create'));
router.use(require('./get'));
router.use(require('./find'));

module.exports = router;
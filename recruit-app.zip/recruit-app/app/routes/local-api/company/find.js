const express = require('express');
const router  = express.Router();
const auth = appRequire('service', 'auth');
const db = appRequire('service', 'db');
const {handleResponseError} = appRequire('service', 'error');
const findCompanies = require('../../helpers/find-companies');

router.get('/:id(\\d+)', (req, res) => {

    findCompanies(req.session.token, {id: req.params.id}, res);

});

module.exports = router;
const express = require('express');
const router  = express.Router();
const auth = appRequire('service', 'auth');
const db = appRequire('service', 'db');
const {handleResponseError} = appRequire('service', 'error');

router.post('/cancel', (req, res) => {
    auth.getUserDetails(
        req.session.token,
        function (response) {
            if (response.hasOwnProperty('user')) {
                db.CompanyInvite.findByPrimary(req.body.invite)
                    .then(
                        companyInvite => {
                            if (companyInvite === null) {
                                return res.json(
                                    {
                                        error: 'Invite is invalid'
                                    }
                                );
                            }

                            db.UserCompany.find(
                                {
                                    where: {
                                        user: response.user.id.toString(),
                                        companyId: Number.parseInt(companyInvite.companyId)
                                    }
                                }
                            ).then(
                                userCompany => {
                                    if (null === userCompany) {
                                        return res.json(
                                            {
                                                error: 'Permission denied'
                                            }
                                        )
                                    }

                                    db.Company.findByPrimary(userCompany.companyId)
                                        .then(
                                            company => {
                                                if (company === null) {
                                                    return res.json(
                                                        {
                                                            error: 'Company is invalid'
                                                        }
                                                    );
                                                }

                                                db.CompanyInvite.update(
                                                    {
                                                        status: req.body.status
                                                    },
                                                    {
                                                        where: {
                                                            id: req.body.invite
                                                        }
                                                    }
                                                ).then(
                                                    () => {
                                                        res.json(
                                                            {
                                                                invite: {
                                                                    status: req.body.status
                                                                }
                                                            }
                                                        )
                                                    }
                                                ).catch(handleResponseError(res))

                                            }
                                        ).catch(handleResponseError(res));
                                }
                            ).catch(handleResponseError(res));
                        }
                    ).catch(handleResponseError(res))
            } else {
                res.json({
                    error: 'User must be logged in'
                })
            }
        }
    );
});

module.exports = router;
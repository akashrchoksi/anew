const express = require('express');
const router = express.Router();

router.use(require('./create'));
router.use(require('./cancel'));
router.use(require('./use'));

module.exports = router;
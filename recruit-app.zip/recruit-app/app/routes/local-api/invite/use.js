const express = require('express');
const router  = express.Router();
const auth = appRequire('service', 'auth');
const db = appRequire('service', 'db');
const {handleResponseError} = appRequire('service', 'error');
const findCompanies = require('../../helpers/find-companies');

router.post('/use', (req, res) => {
    auth.getUserDetails(
        req.session.token,
        function (response) {
            if(response.hasOwnProperty('user')) {

                db.CompanyInvite.find(
                    {
                        where: {
                            email: response.user.email,
                            hash: req.body.hash,
                            status: db.CompanyInvite.status.PENDING
                        }
                    }
                ).then(
                    invite => {
                        if (invite === null) {
                            return res.json({
                                error: 'Invalid company invite hash'
                            })
                        }

                        invite.update({status: db.CompanyInvite.status.USED}).then(
                            () => {

                                db.UserCompany.create(
                                    {
                                        user: response.user.id,
                                        companyId: invite.companyId
                                    }
                                ).then(
                                    () => {
                                        findCompanies(
                                            req.session.token,
                                            {
                                                companyId: invite.companyId
                                            },
                                            res
                                        )
                                    }
                                );
                            }
                        )
                    }
                );
            } else {
                res.json({
                    error: 'User must be logged in'
                })
            }
        }
    )
});

module.exports = router;
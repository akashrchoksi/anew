const express = require('express');
const router  = express.Router();
const auth = appRequire('service', 'auth');
const db = appRequire('service', 'db');
const {handleResponseError} = appRequire('service', 'error');
const {sendMail, Templates} = appRequire('service', 'mail');

router.post('/create', (req, res) => {
    auth.getUserDetails(
        req.session.token,
        function (response) {
            if (response.hasOwnProperty('user')) {

                db.Company.findByPrimary(Number.parseInt(req.body.companyId))
                    .then(
                        company => {
                            if (company === null) {
                                return res.json(
                                    {
                                        error: 'Company is invalid'
                                    }
                                );
                            }

                            db.CompanyInvite.findOrCreate(
                                {
                                    where: {
                                        email: req.body.email,
                                        companyId: company.id,
                                        status: db.CompanyInvite.status.PENDING
                                    }
                                }
                            ).then(
                                ([companyInvite, created]) => {
                                    console.log('Company', companyInvite);
                                    console.log('Created', created);
                                    sendMail(
                                        'Company invite',
                                        Templates.COMPANY_INVITE,
                                        companyInvite.email,
                                        {companyInvite}
                                    ).then(() => {
                                        res.json(
                                            {
                                                created,
                                                invite: companyInvite.toJSON(),
                                            }
                                        );
                                    }).catch(handleResponseError(res));

                                }
                            ).catch(handleResponseError(res))
                        }
                    )

            } else {
                res.json({
                    error: 'User must be logged in'
                })
            }
        }
    );

    db.CompanyInvite.create(
        {
            email: req.body.email
        }
    )
});

module.exports = router;
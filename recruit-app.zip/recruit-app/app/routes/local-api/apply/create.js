const express = require('express');
const router  = express.Router();
const auth = appRequire('service', 'auth');
const db = appRequire('service', 'db');
const {handleResponseError} = appRequire('service', 'error');
const multiparty = require('connect-multiparty');
const multipartyMiddleware = multiparty();
const fs = require('fs');
const path = require('path');

router.post('/create', multipartyMiddleware, (req, res) => {
    auth.getUserDetails(req.session.token, function (response) {
        if (response.user && response.user.role === 'seeker') {

            db.UserInfo.find(
                {
                    where: {
                        userId: response.user.id
                    }
                }
            ).then(
                userInfo => {
                    db.Apply.create(
                        {
                            userInfoId: userInfo.id,
                            jobId: req.body.jobId
                        }
                    ).then(
                        apply => {
                            res.json({
                                apply: userInfo.id
                            })
                        }
                    ).catch(handleResponseError(res))
                }
            ).catch(handleResponseError(res))

        } else {

            const regex = new RegExp('.*\\S+.*');

            if(!regex.test(req.body.firstName)) {
                return res.json({error: 'First Name invalid'});
            } else if (!regex.test(req.body.lastName)) {
                return res.json({error: 'Last Name invalid'});
            } else {

                const userInfo = db.UserInfo.build(
                    {
                        firstName: req.body.firstName,
                        lastName: req.body.lastName,
                        email: req.body.email
                    }
                );

                userInfo.validate().then(
                    validateError => {
                        if (validateError) {
                            res.json({errors: validateError.errors.map(error => error.message)})
                        } else {

                            if (!req.files.cv) {
                                return res.json({error: 'Please upload CV file'});
                            }

                            const readStream = fs.createReadStream(req.files.cv.path);
                            readStream.on('error', handleResponseError(res));

                            const cvPath = '/img/cv/' + Math.random().toString(36).substring(7) + path.extname(req.files.cv.name);
                            const writeStream = fs.createWriteStream(__base + '/public' + cvPath);
                            writeStream.on('error', handleResponseError(res))
                                .on('close', function () {

                                    db.UserInfo.create(
                                        {
                                            firstName: req.body.firstName,
                                            lastName: req.body.lastName,
                                            email: req.body.email,
                                            cv: cvPath
                                        }
                                    ).then(
                                        userInfo => {
                                            db.Apply.create(
                                                {
                                                    userInfoId: userInfo.id,
                                                    jobId: req.body.jobId
                                                }
                                            ).then(apply => res.json({apply})).catch(handleResponseError(res))
                                        }
                                    ).catch(handleResponseError(res))
                                });


                            readStream.pipe(writeStream);
                        }
                    }
                );
            }
        }
    })

});

module.exports = router;
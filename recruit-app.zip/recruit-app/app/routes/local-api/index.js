const express = require('express');
const router  = express.Router();

router.use('/apply', require('./apply/'));
router.use('/company', require('./company/'));
router.use('/info', require('./info/'));
router.use('/invite', require('./invite/'));
router.use('/job', require('./job/'));
router.use('/user', require('./user/'));

module.exports = router;
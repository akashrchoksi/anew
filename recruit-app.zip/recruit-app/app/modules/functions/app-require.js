const path = require('path');

/**
 * Require file relatively to app path
 * @returns {*}
 */
let appRequire = function () {
    return require(path.join(__dirname, '..', '..', path.join.apply(null, arguments)));
};

module.exports = function (app) {
    global.__base = path.join(__dirname, '..', '..');
    global.appRequire = appRequire;
    app.appRequire = appRequire;
};
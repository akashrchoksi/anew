const fs = require('fs');
const path = require('path');
const Gettext = require('node-gettext');
const {po} = require('gettext-parser');

const translationDir = path.join(__dirname, 'translations');
const locales = ['en_US', 'es_ES'];

const gt = new Gettext();

for (const locale of locales) {
    const filePath = path.join(translationDir, locale + '.po');
    const translationContent = fs.readFileSync(filePath);
    const parsedTranslation = po.parse(translationContent);
    gt.addTranslations(locale, 'messages', parsedTranslation);
}

module.exports = gt;
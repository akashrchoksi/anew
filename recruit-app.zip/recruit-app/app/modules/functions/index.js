module.exports = app => {
    const appRequire = require('./app-require');
    appRequire(app);
    global.gt = require('./locale');
};
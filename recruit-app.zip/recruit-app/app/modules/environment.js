module.exports = () => {
    let dotenv = require('dotenv');
    dotenv.config({path: 'variables.env'});
};
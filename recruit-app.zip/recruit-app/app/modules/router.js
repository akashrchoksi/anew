/**
 * @param app
 */
module.exports = app => {
    app.use(app.appRequire('routes'));
};
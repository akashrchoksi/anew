const {Sequelize} = appRequire('service', 'db');

function handleResponseError(response) {

    return error => {
        if (error instanceof Sequelize.ValidationError) {

            response.json(
                {
                    errors: Object.values(error.errors).map(error => error.message)
                }
            );

        } else {
            response.json(
                {
                    errors: [
                        'Something gone wrong'
                    ]
                }
            );
        }
    }
}

module.exports = {
    handleResponseError
};
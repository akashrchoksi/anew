module.exports = {
    acceptParams: require('./accept-params'),
    errorMessage: require('./error-response'),
};
module.exports = Object.assign(
    require('./orm'),
    require('./models/Category'),
    require('./models/Job'),
    require('./models/JobVersion'),
    require('./models/Company'),
    require('./models/UserCompany'),
    require('./models/CompanyInvite'),
    require('./models/Skill'),
    require('./models/SkillJob'),
    require('./models/UserInfo'),
    require('./models/Apply')
);


const { orm, Sequelize } = require('../orm');
const { SkillJob } = require('./SkillJob');

/**
 * @type Model
 */
const Skill = orm.define(
    'Skill',
    {
        id: {
            type: Sequelize.DataTypes.INTEGER,
            primaryKey: true,
            field: 'id',
            autoIncrement: true
        },
        name: {
            type: Sequelize.DataTypes.STRING,
            field: 'name'
        },
        count: {
            type: Sequelize.DataTypes.INTEGER,
            field: 'count'
        },
        createdAt: {
            type: Sequelize.DataTypes.DATE,
            field: 'created_at'
        },
        updatedAt: {
            type: Sequelize.DataTypes.DATE,
            field: 'updated_at'
        }
    },
    {
        classMethods: {
            tableName: 'skills',
        },
        createdAt: 'created_at',
        updatedAt: 'updated_at',
    }
);

module.exports = {
    Skill
};
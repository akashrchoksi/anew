const { orm, Sequelize } = require('../orm');
/**
 * @type Model
 */
const Apply = orm.define(
    'Apply',
    {
        id: {
            type: Sequelize.DataTypes.INTEGER,
            primaryKey: true,
            field: 'id',
            autoIncrement: true
        },
        userInfoId: {
            type: Sequelize.DataTypes.INTEGER,
            field: 'user_info_id',
        },
        jobId: {
            type: Sequelize.DataTypes.INTEGER,
            field: 'job_id'
        },
        createdAt: {
            type: Sequelize.DataTypes.DATE,
            field: 'created_at'
        },
        updatedAt: {
            type: Sequelize.DataTypes.DATE,
            field: 'updated_at'
        }
    },
    {
        classMethods: {
            tableName: 'apply'
        }
    }
);

module.exports = {
    Apply
};
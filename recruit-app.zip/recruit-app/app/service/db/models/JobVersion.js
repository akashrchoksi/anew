const {orm, Sequelize} = require('../orm');

const {Category} = require('./Category');
const {Apply} = require('./Apply');
const {UserInfo} = require('./UserInfo');
const {SkillJob} = require('./SkillJob');
const {Skill} = require('./Skill');
const {Job} = require('./Job');
const {Company} = require('./Company');
const {UserCompany} = require('./UserCompany');

/**
 * @type Model
 */
const JobVersion = orm.define(
    'JobVersion',
    {
        jobId: {
            type: Sequelize.DataTypes.INTEGER,
            field: 'job_id'
        },
        title: {
            type: Sequelize.DataTypes.STRING,
            field: 'title',
            validate: {
                symbols(value) {
                    if (value.length < 3 || value.length >= 40) {
                        throw new Error('Title requires minimum 3 symbols and maximum 40 symbols. ' +
                            'You have ' + value.length
                        );
                    }
                },
                notEmpty: {
                    args: true,
                    msg: 'Title cannot be empty'
                }
            }
        },
        annualPay: {
            type: Sequelize.DataTypes.INTEGER,
            field: 'annual_pay',
            get() {
                let annualPay = this.getDataValue('annualPay');
                if (!annualPay) return annualPay;

                annualPay.toString = function () {
                    return this[0] === this[1] ? this[0] : `${this[0]} - ${this[1]}`;
                };

                return annualPay;
            }
        },
        activeRange: {
            type: Sequelize.DataTypes.ARRAY(Sequelize.DataTypes.DATE),
            field: 'active_range'
        },
        last: {
            type: Sequelize.DataTypes.BOOLEAN
        },
        shortDescription: {
            type: Sequelize.DataTypes.STRING,
            field: 'short_description',
            validate: {
                symbols(value) {
                    if (value.length <= 5 || value.length >= 150) {
                        throw new Error('Short description requires minimum 5 symbols and maximum 150 symbols. ' +
                            'You have ' + value.length
                        );
                    }
                },
                notEmpty: {
                    args: true,
                    msg: 'Short Description cannot be empty'
                }
            }
        },
        longDescription: {
            type: Sequelize.DataTypes.STRING,
            field: 'long_description',
            validate: {
                symbols(value) {
                    const clearText = value.replace(/<\/?[^>]+(>|$)/g, "");
                    if (clearText.length <= 100 || clearText.length >= 25000) {
                        throw new Error('Long description requires minimum 100 symbols and maximum 25000 symbols. ' +
                            'You have ' + clearText.length
                        );
                    }
                },
                notEmpty: {
                    args: true,
                    msg: 'Long Description cannot be empty'
                }
            }
        },
        employmentType: {
            type: Sequelize.DataTypes.STRING,
            field: 'employment_type',
            get() {
                return gt.gettext(this.getDataValue('employmentType'));
            }
        },
        categoryId: {
            type: Sequelize.DataTypes.INTEGER,
            field: 'category_id',
        },
        userInfoId: {
            type: Sequelize.DataTypes.INTEGER,
            field: 'user_info_id'
        },
        locations: {
            type: Sequelize.DataTypes.STRING,
            field: 'locations',
            validate: {
                notEmpty: {
                    args: true,
                    msg: 'Location cannot be empty'
                }
            }
        },
        publicFields: {
            type: Sequelize.DataTypes.ARRAY(Sequelize.DataTypes.STRING),
            field: 'public_fields'
        },
        createdAt: {
            type: Sequelize.DataTypes.DATE,
            field: 'created_at'
        },
        updatedAt: {
            type: Sequelize.DataTypes.DATE,
            field: 'updated_at'
        }
    },
    {
        classMethods: {
            tableName: 'job_versions',
        }
    }
);

Job.putAdditionalFields = function (jobs) {
    return new Promise(
        (resolve, reject) => {
            if (!jobs || jobs.length === 0) {
                resolve(jobs);
            } else {
                const promises = [];
                const putJobVersion = function (job) {
                    return new Promise(
                        (resolve, reject) => {
                            JobVersion.find(
                                {
                                    where: {
                                        jobId: job.id
                                    },
                                    include: [
                                        {
                                            association: JobVersion.associations.Category
                                        }
                                    ],
                                    order: [['id', 'DESC']]
                                }
                            ).then(
                                jobVersion => {
                                    if (jobVersion) {

                                        jobVersion = jobVersion.toJSON();
                                        delete jobVersion.id;

                                        for (const property in jobVersion) {
                                            if (job instanceof Sequelize.Instance) {
                                                job.setDataValue(property, jobVersion[property]);
                                            } else {
                                                job[property] = jobVersion[property];
                                            }
                                        }
                                    }
                                    resolve(job)
                                }
                            ).catch(error => reject(error))
                        }
                    )
                };

                if (Array.isArray(jobs)) {
                    for (const job of jobs) {
                        promises.push(putJobVersion(job));
                    }
                } else {
                    promises.push(putJobVersion(jobs));
                }

                Promise.all(promises).then(
                    options => {
                        resolve(jobs)
                    }
                ).catch(error => reject(error));
            }
        }
    )
};

Job.newVersion = (job, options, done) => {
    JobVersion.create(Object.assign(options.version, {jobId: job.id}))
        .then(() => done(null, options))
        .catch(error => {done(error)});
};

Job.hook('afterCreate', Job.newVersion);
Job.hook('afterUpdate', Job.newVersion);

Job.hook('afterFind', (jobs, options, done) => {
    Job.putAdditionalFields(jobs).then(jobs => {done(null, options)}).catch(error => done(error));
});

Company.associations.Jobs = Company.hasMany(Job, {foreignKey: 'companyId'});

JobVersion.associations = {
    Category: JobVersion.belongsTo(Category, {as: 'category'}),
    Job: JobVersion.belongsTo(Job, {as: 'job'})
};

Job.associations = {
    Applies: Job.hasMany(Apply, {as: 'applies', foreignKey: 'jobId'}),
    SkillJobs: Job.hasMany(SkillJob, {as: 'skillJobs', foreignKey: 'jobId'}),
    JobVersions: Job.hasMany(JobVersion, {as: 'jobVersions', foreignKey: 'jobId'}),
    Company: Job.belongsTo(Company, {as: 'company'})
};

UserInfo.associations = {
    Applies: UserInfo.hasMany(Apply, {as: 'applies', foreignKey: 'userInfoId'})
};

Apply.associations = {
    UserInfo: Apply.belongsTo(UserInfo, {as: 'userInfo'}),
    Job: Apply.belongsTo(Job, {as: 'job'})
};

SkillJob.assotiations = {
    Skill: SkillJob.belongsTo(Skill, {as: 'skill'})
};

module.exports = {
    JobVersion
};
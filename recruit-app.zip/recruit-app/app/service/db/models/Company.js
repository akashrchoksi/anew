const { orm, Sequelize } = require('../orm');
const {CompanyInvite} = require('./CompanyInvite');
const employeeCount = [
    'From 1 to 10',
    'From 10 to 50',
    'From 50 to 100',
    'From 100 to 500',
    'From 500 to 1000'
];

/**
 * @type Model
 */
const Company = orm.define(
    'Company',
    {
        name: {
            type: Sequelize.DataTypes.STRING,
            field: 'name',
            unique: {
                args: true,
                msg: 'The name is not unique'
            },
            validate: {
                symbols(value) {
                    if (value.length <= 3 || value.length >= 128) {
                        throw new Error('Name requires minimum 3 symbols and maximum 128 symbols. ' +
                            'You have ' + value.length
                        );
                    }
                },
                notEmpty: {
                    args: true,
                    msg: 'Name cannot be empty'
                },
                isAlphanumeric: {
                    args: true,
                    msg: 'In the field company name only numbers and symbols'
                },
            }
        },
        description: {
            type: Sequelize.DataTypes.TEXT,
            field: 'description',
            validate: {
                symbols(value) {
                    if (value.length <= 3 || value.length >= 128) {
                        throw new Error('Description requires minimum 3 symbols and maximum 128 symbols. ' +
                            'You have ' + value.length
                        );
                    }
                },
                notEmpty: {
                    args: true,
                    msg: 'Description cannot be empty'
                }
            }
        },
        locations: {
            type: Sequelize.DataTypes.STRING,
            field: 'locations',
            validate: {
                notEmpty: {
                    args: true,
                    msg: 'Location cannot be empty'
                }
            }
        },
        employeeCount: {
            type: Sequelize.DataTypes.STRING,
            field: 'employee_count',
            validate: {
                symbols(value) {
                    const intValue = Number.parseInt(value);
                    if (value === '' || intValue < 0 || intValue >= employeeCount.length) {
                        throw new Error('Employee count is not valid');
                    }
                }
            },
            get() {
                return gt.gettext(this.getDataValue('employeeCount'));
            }
        },
        foundedYear: {
            type: Sequelize.DataTypes.DATE,
            field: 'founded_year',
            validate: {
                notEmpty: {
                    args: true,
                    msg: 'Founded year is invalid'
                }
            },
            get() {
                return this.getDataValue('foundedYear').getFullYear();
            }
        },
        website: {
            type: Sequelize.DataTypes.STRING,
            field: 'website',
            allowNull: true,
            validate: {
                isUrl: {
                    args: true,
                    msg: 'Url website is not valid'
                },
                is: {
                    args: ['^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)+' +
                    '([a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$'],
                    msg: 'Check for url format (http://example.com)'
                }
            }
        },
        photoUrl: {
            type: Sequelize.DataTypes.STRING,
            field: 'photo_url',
            validate: {
                notEmpty: {
                    args: true,
                    msg: 'Photo cannot be empty'
                }
            }
        },
        createdAt: {
            type: Sequelize.DataTypes.DATE,
            field: 'created_at'
        },
        updatedAt: {
            type: Sequelize.DataTypes.DATE,
            field: 'updated_at'
        }
    },
    {
        classMethods: {
            tableName: 'companies',
            employeeCount
        }
    }
);

Company.associations = {

    Invites: Company.hasMany(CompanyInvite, {foreignKey: 'companyId'})
};

module.exports = {
    Company
};
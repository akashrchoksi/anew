const { orm, Sequelize } = require('../orm');
const { Company } = require('./Company');

/**
 * @type Model
 */
const UserCompany = orm.define(
    'UserCompany',
    {
        user: {
            type: Sequelize.DataTypes.STRING,
            field: 'user'
        },
        companyId: {
            type: Sequelize.DataTypes.INTEGER,
            field: 'company_id'
        },
        createdAt: {
            type: Sequelize.DataTypes.DATE,
            field: 'created_at'
        },
        updatedAt: {
            type: Sequelize.DataTypes.DATE,
            field: 'updated_at'
        }
    },
    {
        classMethods: {
            tableName: 'users_companies'
        }
    }
);

UserCompany.associations = {
    Company: UserCompany.belongsTo(Company, {as: 'company'})
};

module.exports = {
    UserCompany
};
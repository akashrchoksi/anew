const { orm, Sequelize } = require('../orm');

/**
 * @type Model
 */
const Category = orm.define(
    'Category',
    {
        name: {
            type: Sequelize.DataTypes.STRING,
            field: 'name',
            validate: {
                symbols(value) {
                    if (value.length > 3 && value.length < 40) {
                        throw new Error('Name requires minimum 3 symbols and maximum 40 symbols. ' +
                            'You have ' + value.length
                        );
                    }
                }
            },
            get() {
                return gt.gettext(this.getDataValue('name'));
            }
        },
        parentId: {
            type: Sequelize.DataTypes.INTEGER,
            field: 'parent_id'
        },
        createdAt: {
            type: Sequelize.DataTypes.DATE,
            field: 'created_at'
        },
        updatedAt: {
            type: Sequelize.DataTypes.DATE,
            field: 'updated_at'
        }
    },
    {
        classMethods: {
            tableName: 'categories'
        }
    }
);

Category.associations = {
    Categories: Category.hasMany(Category, {as: 'categories', foreignKey: 'parentId'})
};


module.exports = {
    Category
};
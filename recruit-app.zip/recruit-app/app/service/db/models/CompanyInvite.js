const { orm, Sequelize } = require('../orm');
let stringHash = require('string-hash');

/**
 * @type Model
 */
const CompanyInvite = orm.define(
    'CompanyInvite',
    {
        hash: {
            type: Sequelize.DataTypes.STRING,
            field: 'hash'
        },
        companyId: {
            type: Sequelize.DataTypes.INTEGER,
            field: 'company_id'
        },
        email: {
            type: Sequelize.DataTypes.STRING,
            field: 'email',
            validate: {
                symbols(value) {
                    if (value.length <= 6 || value.length > 128) {
                        throw new Error('Email requires minimum 6 symbols and maximum 128 symbols. ' +
                            'You have ' + value.length
                        );
                    }
                },
                isEmail: {
                    msg: 'Email is not valid'
                }
            }
        },
        status: {
            type: Sequelize.DataTypes.STRING,
            field: 'status'
        },
        createdAt: {
            type: Sequelize.DataTypes.DATE,
            field: 'created_at'
        },
        updatedAt: {
            type: Sequelize.DataTypes.DATE,
            field: 'updated_at'
        }
    },
    {
        classMethods: {
            tableName: 'company_invites',
            status: {
                PENDING: 'pending',
                CANCELED: 'canceled',
                USED: 'used',
            }
        }
    }
);

CompanyInvite.hook(
    'beforeCreate',
    function (company, options, done) {
        const date = new Date();
        const dateHash = `${date.getSeconds().toString()}${date.getMinutes().toString()}${date.getMilliseconds()}${date.getHours()}`;
        company.hash = `${stringHash(dateHash)}${Math.random().toString(36).substr(2, 9)}`;
        done(null, company);
    }
);

module.exports = {
    CompanyInvite
};
const {orm, Sequelize} = require('../orm');

/**
 * @type Model
 */
const Job = orm.define(
    'Job',
    {
        companyId: {
            type: Sequelize.DataTypes.INTEGER,
            field: 'company_id'
        },
        user: {
            type: Sequelize.DataTypes.STRING,
            field: 'user'
        },
        status: {
            type: Sequelize.DataTypes.STRING,
            field: 'status'
        },
        createdAt: {
            type: Sequelize.DataTypes.DATE,
            field: 'created_at'
        },
        updatedAt: {
            type: Sequelize.DataTypes.DATE,
            field: 'updated_at'
        }
    },
    {
        classMethods: {
            tableName: 'jobs',
            employmentTypes: [
                'Contract Job',
                'Permanent Job',
            ],
            statuses: {
                ACTIVE: 'active',
                DRAW: 'draw',
                TRASH: 'trash'
            }
        }
    }
);

module.exports = {
    Job
};
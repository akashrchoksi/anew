const {orm, Sequelize} = require('../orm');

/**
 * @type Model
 */
const UserInfo = orm.define(
    'UserInfo',
    {
        id: {
            type: Sequelize.DataTypes.INTEGER,
            primaryKey: true,
            field: 'id',
            autoIncrement: true
        },
        email: {
            type: Sequelize.DataTypes.STRING,
            field: 'email',
            validate: {
                isEmail: {
                    args: true,
                    msg: 'Email is invalid'
                },
                symbols(value) {
                    if (value.length <= 3 || value.length >= 128) {
                        throw new Error('Email requires minimum 3 symbols and maximum 128 symbols. ' +
                            'You have ' + value.length
                        );
                    }
                }
            }
        },
        userId: {
            type: Sequelize.DataTypes.INTEGER,
            field: 'user_id',
            unique: true,
            allowNull: true
        },
        firstName: {
            type: Sequelize.DataTypes.STRING,
            field: 'first_name',
            symbols(value) {
                if (value.length <= 3 || value.length >= 128) {
                    throw new Error('First name requires minimum 3 symbols and maximum 128 symbols. ' +
                        'You have ' + value.length
                    );
                }
            }
        },
        lastName: {
            type: Sequelize.DataTypes.STRING,
            field: 'last_name',
            symbols(value) {
                if (value.length <= 3 || value.length >= 128) {
                    throw new Error('Last name requires minimum 3 symbols and maximum 128 symbols. ' +
                        'You have ' + value.length
                    );
                }
            }
        },
        phone: {
            type: Sequelize.DataTypes.STRING,
            allowNull: true,
            field: 'phone',
        },
        fax: {
            type: Sequelize.DataTypes.BOOLEAN,
            allowNull: true,
            field: 'fax'
        },
        cv: {
            type: Sequelize.DataTypes.STRING,
            allowNull: true,
        },
        createdAt: {
            type: Sequelize.DataTypes.DATE,
            field: 'created_at'
        },
        updatedAt: {
            type: Sequelize.DataTypes.DATE,
            field: 'updated_at'
        }
    },
    {
        classMethods: {
            tableName: 'users_info'
        },
        createdAt: 'created_at',
        updatedAt: 'updated_at'
    }
);

module.exports = {
    UserInfo
};
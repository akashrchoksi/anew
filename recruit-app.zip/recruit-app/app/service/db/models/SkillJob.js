const { orm, Sequelize } = require('../orm');
const { Job } = require('./Job');

/**
 * @type Model
 */
const SkillJob = orm.define(
    'SkillJob',
    {
        id: {
            type: Sequelize.DataTypes.INTEGER,
            primaryKey: true,
            field: 'id',
            autoIncrement: true
        },
        skillId: {
            type: Sequelize.DataTypes.INTEGER,
            field: 'skill_id',
        },
        jobId: {
            type: Sequelize.DataTypes.INTEGER,
            field: 'job_id'
        },
        createdAt: {
            type: Sequelize.DataTypes.DATE,
            field: 'created_at'
        },
        updatedAt: {
            type: Sequelize.DataTypes.DATE,
            field: 'updated_at'
        }
    },
    {
        classMethods: {
            tableName: 'skills_job'
        }
    }
);

module.exports = {
    SkillJob
};
'use strict';

module.exports = {
    up: function (queryInterface, Sequelize) {
        queryInterface.changeColumn('users_info', 'user_id', {
            type: 'INTEGER USING CAST("user_id" as INTEGER)',
            allowNull: true
        });
    },

    down: function (queryInterface, Sequelize) {
        queryInterface.changeColumn('users_info', 'user_id', {
            type: 'INTEGER USING CAST("user_id" as INTEGER)',
            allowNull: false
        });
    }
};

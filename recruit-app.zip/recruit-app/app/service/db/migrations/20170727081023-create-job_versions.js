'use strict';

module.exports = {
    up: function (queryInterface, Sequelize) {

        queryInterface.removeColumn('jobs', 'title');
        queryInterface.removeColumn('jobs', 'short_description');
        queryInterface.removeColumn('jobs', 'long_description');
        queryInterface.removeColumn('jobs', 'category_id');
        queryInterface.removeColumn('jobs', 'employment_type');
        queryInterface.removeColumn('jobs', 'annual_pay');
        queryInterface.removeColumn('jobs', 'locations');
        queryInterface.removeColumn('jobs', 'public_fields');

        queryInterface.createTable(
            'job_versions',
            {
                id: {
                    type: Sequelize.INTEGER,
                    primaryKey: true,
                    autoIncrement: true
                },
                job_id: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'jobs',
                        key: 'id'
                    },
                },
                title: {
                    type: Sequelize.STRING,
                    allowNull: false
                },
                short_description: {
                    type: Sequelize.TEXT,
                    allowNull: false
                },
                long_description: {
                    type: Sequelize.TEXT,
                    allowNull: false
                },
                category_id: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'categories',
                        key: 'id'
                    },
                },
                locations: {
                    type: Sequelize.STRING,
                    allowNull: true
                },
                employment_type: {
                    type: Sequelize.STRING
                },
                annual_pay: {
                    type: Sequelize.INTEGER
                },
                public_fields: {
                    type: Sequelize.ARRAY(Sequelize.STRING)
                },
                user_info_id: {
                    type: Sequelize.INTEGER,
                    allowNull: false,
                    references: {
                        model: 'users_info',
                        key: 'id'
                    }
                },
                created_at: {
                    type: Sequelize.DATE
                },
                updated_at: {
                    type: Sequelize.DATE
                }
            }
        );
    },

    down: function (queryInterface, Sequelize) {

        queryInterface.addColumn('jobs', 'title', {
            type: Sequelize.STRING,
            allowNull: false
        });

        queryInterface.addColumn('jobs', 'short_description', {
            type: Sequelize.TEXT,
            allowNull: false
        });

        queryInterface.addColumn('jobs', 'long_description', {
            type: Sequelize.TEXT,
            allowNull: false
        });

        queryInterface.addColumn('jobs', 'category_id', {
            type: Sequelize.INTEGER,
            references: {
                model: 'categories',
                key: 'id'
            },
        });

        queryInterface.addColumn('jobs', 'employment_type', {
            type: Sequelize.STRING
        });

        queryInterface.addColumn('jobs', 'annual_pay', {
            type: Sequelize.INTEGER
        });

        queryInterface.addColumn('jobs', 'locations', {
            type: Sequelize.STRING,
            allowNull: false
        });

        queryInterface.addColumn('jobs', 'public_fields', {
            type: Sequelize.ARRAY(Sequelize.STRING)
        });

        queryInterface.dropTable('job_versions');
    }
};

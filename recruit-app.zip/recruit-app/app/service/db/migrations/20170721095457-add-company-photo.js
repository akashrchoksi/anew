'use strict';

module.exports = {
    up: function (queryInterface, Sequelize) {
        queryInterface.addColumn(
            'companies',
            'photo_url',
            {
                type: Sequelize.STRING,
                allowNull: true
            }
        )
    },

    down: function (queryInterface, Sequelize) {
        queryInterface.removeColumn('companies', 'photo_url');
    }
};

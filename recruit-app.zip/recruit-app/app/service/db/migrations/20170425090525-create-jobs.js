'use strict';

module.exports = {
    up: function (queryInterface, Sequelize) {
        return queryInterface.createTable(
            'jobs',
            {
                id: {
                    type: Sequelize.INTEGER,
                    primaryKey: true,
                    autoIncrement: true
                },
                title: {
                    type: Sequelize.STRING,
                    allowNull: false
                },
                short_description: {
                    type: Sequelize.TEXT,
                    allowNull: false
                },
                long_description: {
                    type: Sequelize.TEXT,
                    allowNull: false
                },
                company_id: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'companies',
                        key: 'id'
                    },
                },
                category_id: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'categories',
                        key: 'id'
                    },
                },
                employment_type: {
                    type: Sequelize.STRING
                },
                annual_pay: {
                    type: Sequelize.INTEGER
                },
                user: {
                    type: Sequelize.STRING,
                    allowNull: false
                },
                created_at: {
                    type: Sequelize.DATE
                },
                updated_at: {
                    type: Sequelize.DATE
                }
            }
        );
    },
    down: function (queryInterface, Sequelize) {
        return queryInterface.dropTable('jobs');
    }
};

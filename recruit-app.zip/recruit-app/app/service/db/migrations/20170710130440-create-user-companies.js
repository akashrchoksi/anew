'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
      return queryInterface.createTable(
          'users_companies',
          {
              id: {
                  type: Sequelize.INTEGER,
                  primaryKey: true,
                  autoIncrement: true
              },
              user: {
                  type: Sequelize.STRING,
                  allowNull: false
              },
              company_id: {
                  type: Sequelize.INTEGER,
                  references: {
                      model: 'companies',
                      key: 'id'
                  },
              },
              created_at: {
                  type: Sequelize.DATE
              },
              updated_at: {
                  type: Sequelize.DATE
              }
          }
      );
  },

  down: function (queryInterface, Sequelize) {
      return queryInterface.dropTable('users_companies');
  }
};

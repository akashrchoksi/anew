'use strict';

module.exports = {
    up: function (queryInterface, Sequelize) {
        queryInterface.addIndex(
            'companies',
            ['name'],
            {
                indexName: 'nameCompanyUniqueIndex',
                indicesType: 'UNIQUE'
            }
        )
    },

    down: function (queryInterface, Sequelize) {
        queryInterface.removeIndex('companies', 'nameCompanyUniqueIndex');
    }
};

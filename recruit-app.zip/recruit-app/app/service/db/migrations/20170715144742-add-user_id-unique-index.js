'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
      queryInterface.addIndex(
          'users_info',
          ['user_id'],
          {
              indexName: 'userIdUniqueIndex',
              indicesType: 'UNIQUE'
          }
      )
  },

  down: function (queryInterface, Sequelize) {
      queryInterface.removeIndex('users_info', 'userIdUniqueIndex');
  }
};

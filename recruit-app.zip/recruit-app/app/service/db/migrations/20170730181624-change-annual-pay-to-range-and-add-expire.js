'use strict';

module.exports = {
    up: function (queryInterface, Sequelize) {
        queryInterface.removeColumn('job_versions', 'annual_pay');

        queryInterface.addColumn('job_versions', 'annual_pay', {
            type: Sequelize.ARRAY(Sequelize.INTEGER),
            defaultValue: [0,0]
        });
        queryInterface.addColumn('job_versions', 'active_range', {
            type: Sequelize.ARRAY(Sequelize.DATE)
        })
    },

    down: function (queryInterface, Sequelize) {
        queryInterface.removeColumn('job_versions', 'active_range');
        queryInterface.removeColumn('job_versions', 'annual_pay');
        queryInterface.addColumn('job_versions', 'annual_pay', {
            type: Sequelize.INTEGER,
            defaultValue: 0
        });
    }
};

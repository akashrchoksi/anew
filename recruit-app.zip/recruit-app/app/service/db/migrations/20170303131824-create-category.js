'use strict';

module.exports = {
    up: function (queryInterface, Sequelize) {
        return queryInterface.createTable(
            'categories',
            {
                id: {
                    type: Sequelize.INTEGER,
                    primaryKey: true,
                    autoIncrement: true
                },
                name: {
                    type: Sequelize.STRING,
                    allowNull: false
                },
                parent_id: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'categories',
                        key: 'id'
                    },
                },
                created_at: {
                    type: Sequelize.DATE
                },
                updated_at: {
                    type: Sequelize.DATE
                }
            }
        );
    },
    down: function (queryInterface) {
        return queryInterface.dropTable('categories');
    }

};

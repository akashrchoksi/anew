'use strict';

module.exports = {
    up: function (queryInterface, Sequelize) {
        queryInterface.removeColumn(
            'companies',
            'web_site'
        );
        queryInterface.addColumn(
            'companies',
            'website',
            {
                type: Sequelize.STRING,
                allowNull: true
            }
        )
    },



    down: function (queryInterface, Sequelize) {
        queryInterface.addColumn(
            'companies',
            'web_site',
            {
                type: Sequelize.STRING,
                allowNull: false
            }
        );
        queryInterface.removeColumn(
            'companies',
            'website'
        )
    }
};

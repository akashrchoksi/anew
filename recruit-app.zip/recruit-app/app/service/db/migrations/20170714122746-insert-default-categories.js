'use strict';

const categories = ['IT', 'BUSINESS', 'Building', 'Engineering'];

module.exports = {
    up: function (queryInterface) {

        for (const category of categories) {
            queryInterface.sequelize.query(
                `INSERT INTO categories ("name", "created_at", "updated_at") VALUES ('${category}', current_timestamp, current_timestamp)`);

        }
    }
};

'use strict';

module.exports = {
    up: function (queryInterface, Sequelize) {
        return queryInterface.createTable(
            'apply',
            {
                id: {
                    type: Sequelize.INTEGER,
                    primaryKey: true,
                    autoIncrement: true
                },
                user_info_id: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'users_info',
                        key: 'id'
                    },
                },
                job_id: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'jobs',
                        key: 'id'
                    },
                },
                created_at: {
                    type: Sequelize.DATE
                },
                updated_at: {
                    type: Sequelize.DATE
                }
            }
        );
    },
    down: function (queryInterface) {
        return queryInterface.dropTable('apply');
    }
};

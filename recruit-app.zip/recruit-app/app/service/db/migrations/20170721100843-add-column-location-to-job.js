'use strict';

module.exports = {
    up: function (queryInterface, Sequelize) {
        queryInterface.addColumn(
            'jobs',
            'locations',
            {
                type: Sequelize.STRING,
                allowNull: true
            }
        )
    },

    down: function (queryInterface, Sequelize) {
        queryInterface.removeColumn('jobs', 'locations');
    }
};

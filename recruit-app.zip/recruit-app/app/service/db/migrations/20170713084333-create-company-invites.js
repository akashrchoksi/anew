'use strict';

module.exports = {
    up: function (queryInterface, Sequelize) {
        return queryInterface.createTable(
            'company_invites',
            {
                id: {
                    type: Sequelize.INTEGER,
                    primaryKey: true,
                    autoIncrement: true
                },
                company_id: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'companies',
                        key: 'id'
                    }
                },
                hash: {
                    type: Sequelize.STRING,
                    allowNull: false
                },
                email: {
                    type: Sequelize.STRING,
                    allowNull: false
                },
                status: {
                    type: Sequelize.STRING,
                    allowNull: false,
                    defaultValue: 'pending'
                },
                created_at: {
                    type: Sequelize.DATE
                },
                updated_at: {
                    type: Sequelize.DATE
                }
            }
        );
    },
    down: function (queryInterface) {
        return queryInterface.dropTable('company_invites');
    }
};

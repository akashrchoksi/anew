'use strict';

module.exports = {
    up: function (queryInterface, Sequelize) {
        return queryInterface.createTable(
            'skills_job',
            {
                id: {
                    type: Sequelize.INTEGER,
                    primaryKey: true,
                    autoIncrement: true
                },
                skill_id: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'skills',
                        key: 'id'
                    },
                },
                job_id: {
                    type: Sequelize.INTEGER,
                    references: {
                        model: 'jobs',
                        key: 'id'
                    },
                },
                created_at: {
                    type: Sequelize.DATE
                },
                updated_at: {
                    type: Sequelize.DATE
                }
            }
        );
    },
    down: function (queryInterface) {
        return queryInterface.dropTable('skills_job');
    }
};

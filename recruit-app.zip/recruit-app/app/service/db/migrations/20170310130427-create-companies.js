'use strict';

module.exports = {
    up: function (queryInterface, Sequelize) {
        return queryInterface.createTable(
            'companies',
            {
                id: {
                    type: Sequelize.INTEGER,
                    primaryKey: true,
                    autoIncrement: true
                },
                name: {
                    type: Sequelize.STRING,
                    allowNull: false
                },
                description: {
                    type: Sequelize.TEXT,
                    allowNull: false
                },
                locations: {
                    type: Sequelize.STRING,
                    allowNull: false
                },
                employee_count: {
                    type: Sequelize.STRING,
                    allowNull: false
                },
                founded_year: {
                    type: Sequelize.DATE,
                    allowNull: false
                },
                web_site: {
                    type: Sequelize.STRING,
                    allowNull: false
                },
                created_at: {
                    type: Sequelize.DATE
                },
                updated_at: {
                    type: Sequelize.DATE
                }
            }
        );
    },
    down: function (queryInterface, Sequelize) {
        return queryInterface.dropTable('companies');
    }
};

'use strict';

module.exports = {
    up: function (queryInterface, DataTypes) {
        queryInterface.addColumn('jobs', 'status', {
            type: DataTypes.STRING,
            defaultValue: 'draw'
        });

        queryInterface.addColumn('jobs', 'public_fields', {
            type: DataTypes.ARRAY(DataTypes.STRING)
        });
    },

    down: function (queryInterface, DataTypes) {
        queryInterface.removeColumn('jobs', 'status');
        queryInterface.removeColumn('jobs', 'public_fields');
    }
};

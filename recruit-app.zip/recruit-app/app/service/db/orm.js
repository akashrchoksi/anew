const path = require('path');
const Sequelize = require('sequelize');
const env   = process.env.NODE_ENV || 'development';
const config = require(path.join(__dirname, '.', 'config', 'config'))[env];
const orm = new Sequelize(process.env.DB_NAME, process.env.DB_USER, config.password, config);

module.exports = {
    orm,
    Sequelize
};
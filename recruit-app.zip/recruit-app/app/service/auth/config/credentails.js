module.exports = {
    base: process.env.AUTH_BASE,
    client_id: process.env.AUTH_CLIENT_ID,
    client_secret: process.env.AUTH_CLIENT_SECRET
};
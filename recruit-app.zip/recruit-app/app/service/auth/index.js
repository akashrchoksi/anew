const request = require('request');
const qs = require('querystring');

const credentials = require('./config/credentails');

const links = {
    loginLink: `${credentials.base}/login/${credentials.client_id}`,
    registerLink: `${credentials.base}/register/${credentials.client_id}`
};

let result = {
    links
};

result.getUserDetails = function (token, onSuccess, onError = function (error) {console.log(error)}) {
    const query = qs.stringify(
        {
            clientId: credentials.client_id,
            clientSecret: credentials.client_secret,
        }
    );

    request.get(
        {
            url: `${credentials.base}/api/login/users/${token}?${query}`
        },
        (error, response, body) => {

            if (error) {
                onError(error);
            } else {
                onSuccess(JSON.parse(body));
            }

        }
    )
};

result.updateUser = function (token, userDetails, onSuccess, onError) {
    const data = Object.assign(
        userDetails,
        {token},
        {
            clientId: credentials.client_id,
            clientSecret: credentials.client_secret,
        }
    );
    request.post(
        {
            url: credentials.base + '/api/login/users',
            form: data
        },
        (error, response, body) => {
            if (error) {
                onError(error);
            } else {
                onSuccess(JSON.parse(body));
            }
        }
    )
};

module.exports = result;
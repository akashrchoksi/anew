const mailer = require('nodemailer');
const path = require('path');
const pug = require('pug');

const transport = mailer.createTransport(
    {
        service: process.env.MAIL_SERVICE,
        auth: {
            user: process.env.MAIL_USER,
            pass: process.env.MAIL_PASSWORD,
        }
    }
);

const Templates = {
    COMPANY_INVITE: 'company-invite.pug'
};

function sendMail(subject, template, to, params = {}, from = process.env.MAIL_FROM) {

    const html = pug.renderFile(path.join(__dirname, 'templates', template), params);

    return new Promise(
        (resolve, reject) => {
            transport.sendMail(
                {
                    from,
                    to,
                    subject,
                    html
                },
                (err, info) => {
                    if (err) {
                        reject(err);
                    } else {
                        resolve(info);
                    }
                }
            );
        }
    )
}

module.exports = {
    transport,
    Templates,
    sendMail
};